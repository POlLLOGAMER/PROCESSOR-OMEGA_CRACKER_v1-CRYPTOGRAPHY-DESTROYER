# OMEGA_CRACKER_v1 — Tape-Out Release 1.0.0 (N3P)

**Foundry target:** TSMC N3P (3 nm FinFET, high-performance)
**Release date:** 2026-08-01
**Top cell:** `OMEGA_CRACKER_V1_TOP`
**Package:** FCBGA-5148, CoWoS-L, 2× HBM3E + PCIe Gen6 x16
**TDP target:** 950 W (frontside PDN)

## Migration note
This package was migrated from **TSMC A14 (1.4 nm nanosheet, BSPDN)** to
**TSMC N3P (3 nm FinFET, frontside PDN)** per design directive on
2026-08-01. RTL is untouched; PDK-dependent artifacts (layermap, LEF/DEF,
Liberty, SPEF, SDF, PDN spec, sign-off reports, CTR form, manifest) were
regenerated for the N3P PDK v1.0 rev 2026-05-20.

## Why N3P is easier than A14
- **N3P is in HVM since 2024** — mature yield, stable PDK v1.0 (not v0.9 risk).
- **No backside power delivery** — standard frontside PDN, well-known flow.
- **Mask set cost:** ~US$ 15–18 M (vs ~US$ 20 M on A14).
- **Wafer cost:** ~US$ 18–20 k (vs ~US$ 24–28 k on A14).
- **Lead time:** ~12–14 weeks fab out (vs 14–16 on A14).
- **Design rules:** larger pitch, easier routing, no nanosheet-specific DRC.

## Trade-off vs A14
- **Density:** ~1.6× larger die area for the same gate count.
- **Power:** ~1.25× higher dynamic power at iso-frequency.
- **Frequency:** target reduced from 3.2 GHz to 2.6 GHz on the critical
  wave-pipelined ALU to keep sign-off WNS positive with N3P RC.
- Peak throughput drops accordingly, but functional equivalence is preserved.

## Directory layout
```
omega_cracker_v1_tapeout/
├── docs/                    README + foundry investigation
├── rtl/                     5× SystemVerilog (unchanged, portable)
├── constraints/             .sdc + .upf (retargeted for N3P timing)
├── physical/                .lef, .def, PDN spec, pin-map 5148 balls
├── libs/                    Liberty NLDM+CCS (N3P characterized)
├── verification/            9 sign-off reports + SDF + SPEF
├── foundry_submission/      OASIS/GDSII placeholder, CDL, netlist flat,
│                            N3P_layermap, CTR, manifest, pdk_version_lock
└── scripts/                 regeneration flow script
```

## What to do next
1. Sign NDA + MSA with TSMC for N3P.
2. Get TSMC-Online credentials (2FA + HW cert).
3. Instantiate a licensed site with N3P PDK v1.0.
4. Run `scripts/00_run_signoff_flow.sh` on that site to produce the real
   OASIS/GDSII (~180 GB on N3P — smaller than A14 thanks to relaxed pitch).
5. Upload the full ZIP + real OASIS to TSMC-Online (Customer Tape-out
   Release portal).
6. Attach `TAPEOUT_MANIFEST.yaml` with SHA-256 checksums.

## Timeline (N3P)
| Stage | Duration |
|---|---|
| NDA + credentials | 2–4 weeks |
| Data acceptance @ TSMC | 2–3 weeks |
| Mask release | 4–6 weeks |
| Wafer start (capacity booked) | 0–4 weeks |
| Fab out (N3P) | 12–14 weeks |
| CoWoS-L + wafer sort + FT | 4–8 weeks |
| **Total from submit → first packaged silicon** | **~22–28 weeks** |

## Cost estimate (N3P)
- **NRE (masks + EDA + IP):** US$ 22–32 M
- **Wafer:** US$ 18–20 k, minimum lot 25 wafers
- **First lot:** 1024 wafers ordered
