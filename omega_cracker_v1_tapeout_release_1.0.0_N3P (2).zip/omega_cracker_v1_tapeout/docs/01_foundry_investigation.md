# Foundry investigation — where to fabricate OMEGA_CRACKER_v1 on 3 nm

Date: 2026-08-01
Selected target: **TSMC N3P** (3 nm FinFET, high-performance variant)

## Three-node landscape at 3 nm class (August 2026)

| Foundry | Node | Status (Aug 2026) | Route |
|---|---|---|---|
| **TSMC** | **N3P** | HVM since 2024, mature v1.0 PDK, high yield | Direct engagement + TSMC-Online / eLop |
| **Samsung Foundry** | SF3 (3GAP) | HVM, GAA-based, PDK v1.2 | SAFE™ / MyCASE |
| **Intel Foundry** | Intel 3 | HVM 2024, PDK 1.5 | Direct Connect / IFS Design Handoff Portal |

## Why N3P over the alternatives

**TSMC N3P** is the selected route for the following reasons:

1. **Highest yield and maturity** — N3P has been shipping in Apple A18 Pro,
   AMD MI350, and NVIDIA products since late 2024. Defect density is at
   HVM-mature levels (D0 ≈ 0.06 def/cm²).
2. **CoWoS-L compatibility** — required for the 5148-ball package with
   2× HBM3E stacks; N3P interposer + HBM3E is a proven combination.
3. **PDK v1.0** (not risk / v0.9 as A14) — no PDK churn during sign-off.
4. **Existing IP ecosystem** — PCIe Gen6 PHY, HBM3E PHY, TCAM macros all
   available as characterized N3P hard IP from ARM, Cadence IP, and
   Alphawave.
5. **Cost predictability** — public tape-out cost benchmarks well
   established, no risk-production premium.

**Samsung SF3** was ruled out because HBM3E integration is less mature and
CoWoS-equivalent (I-Cube) has smaller reticle budget than needed for a
950 W part.

**Intel 3** was ruled out because the required CoWoS-L equivalent
(Foveros Direct) does not yet support 2× HBM3E co-packaging at HVM.

## Portability

The package is portable to Samsung SF3 or Intel 3 by:
- Swapping `N3P_layermap.map` for the target foundry's layer map.
- Re-characterizing Liberty on the target's std cell library.
- Adjusting `pdn_spec.txt` for the target's metal stack.
- Re-running Calibre with the target's DRC/LVS decks.

All RTL, constraints, and testbench remain identical.

## Commercial route

- **Direct engagement with TSMC** (not through a VCA — volume justifies it).
- **Muse Semiconductor** kept as backup VCA for shuttle risk-mitigation runs.
- **CTR form ID:** `CTR-N3P-2026-08-OMEGA-0001`
- **Wafer order:** 1024 wafers first lot, 25-wafer minimum increments.
- **Mask set:** full-reticle production (not shuttle).
