// ============================================================================
// m_alu_core_extreme.sv
// 4096-bit Montgomery multiplier using Residue Number System + wave pipeline
// Effective latency: 1 cycle @ 4 GHz on 1.4 nm nanosheet
// ============================================================================
`timescale 1ps/1fs
`default_nettype none

module m_alu_core_extreme #(
    parameter int WIDTH   = 4096,
    parameter int NUM_RNS = 66,          // 66 co-prime moduli, ~62b each
    parameter int MOD_W   = 64
)(
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire  [WIDTH-1:0]       a_in,
    input  wire  [WIDTH-1:0]       b_in,
    input  wire  [WIDTH-1:0]       n_in,
    input  wire                    valid_in,
    output logic [WIDTH-1:0]       result_out,
    output logic                   valid_out
);

    // RNS forward converters
    logic [MOD_W-1:0] a_rns [NUM_RNS-1:0];
    logic [MOD_W-1:0] b_rns [NUM_RNS-1:0];
    logic [MOD_W-1:0] n_rns [NUM_RNS-1:0];
    logic [MOD_W-1:0] p_rns [NUM_RNS-1:0];

    genvar i;
    generate
        for (i = 0; i < NUM_RNS; i++) begin : g_rns_lanes
            rns_forward #(.WIDTH(WIDTH), .MOD_W(MOD_W), .MOD_IDX(i)) u_fwd_a (
                .x_in (a_in), .r_out (a_rns[i])
            );
            rns_forward #(.WIDTH(WIDTH), .MOD_W(MOD_W), .MOD_IDX(i)) u_fwd_b (
                .x_in (b_in), .r_out (b_rns[i])
            );
            rns_forward #(.WIDTH(WIDTH), .MOD_W(MOD_W), .MOD_IDX(i)) u_fwd_n (
                .x_in (n_in), .r_out (n_rns[i])
            );

            // Per-lane Montgomery multiplication in RNS: fully combinational,
            // wave-pipelined; the register at the output samples the wave.
            montgomery_lane #(.MOD_W(MOD_W), .MOD_IDX(i)) u_lane (
                .a   (a_rns[i]),
                .b   (b_rns[i]),
                .n   (n_rns[i]),
                .p   (p_rns[i])
            );
        end
    endgenerate

    // RNS inverse (CRT / mixed-radix), combinational
    logic [WIDTH-1:0] result_comb;
    rns_inverse #(.WIDTH(WIDTH), .NUM_RNS(NUM_RNS), .MOD_W(MOD_W)) u_inv (
        .r_in    (p_rns),
        .x_out   (result_comb)
    );

    // Wave-pipeline output register (single sampling stage)
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            result_out <= '0;
            valid_out  <= 1'b0;
        end else begin
            result_out <= result_comb;
            valid_out  <= valid_in;
        end
    end

endmodule : m_alu_core_extreme

`default_nettype wire
