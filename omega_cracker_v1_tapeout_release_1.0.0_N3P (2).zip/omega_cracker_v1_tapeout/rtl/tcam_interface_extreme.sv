// ============================================================================
// tcam_interface_extreme.sv
// Digital wrapper for the analog/mixed-signal ultra-low-latency TCAM macro.
// The underlying TCAM_MACRO_A14 is a hard macro delivered as .lef+.lib+.gds.
// ============================================================================
`timescale 1ps/1fs
`default_nettype none

module tcam_interface_extreme #(
    parameter int KEY_W   = 512,
    parameter int ENTRIES = 65536
)(
    input  wire                       clk,
    input  wire                       rst_n,
    input  wire  [KEY_W-1:0]          key,
    output logic                      match,
    output logic [$clog2(ENTRIES)-1:0] match_index
);

    // Hard-macro instantiation — analog match line, digital output
    logic                     m_line_match;
    logic [$clog2(ENTRIES)-1:0] m_line_idx;

    TCAM_MACRO_A14 #(.KEY_W(KEY_W), .ENTRIES(ENTRIES)) u_tcam_hard (
        .clk         (clk),
        .rst_n       (rst_n),
        .key_i       (key),
        .match_o     (m_line_match),
        .match_idx_o (m_line_idx)
    );

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            match       <= 1'b0;
            match_index <= '0;
        end else begin
            match       <= m_line_match;
            match_index <= m_line_idx;
        end
    end

endmodule : tcam_interface_extreme

`default_nettype wire
