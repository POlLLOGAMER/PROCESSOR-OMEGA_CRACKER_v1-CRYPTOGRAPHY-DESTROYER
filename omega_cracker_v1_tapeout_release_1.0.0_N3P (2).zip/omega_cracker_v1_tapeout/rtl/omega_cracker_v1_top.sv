// ============================================================================
// File        : omega_cracker_v1_top.sv
// Project     : OMEGA_CRACKER_v1
// Description : Top-level integration for the OMEGA_CRACKER_v1 chip.
//               Integrates M-ALU (4096-bit Montgomery via RNS + wave-pipeline),
//               Keccak-f[1600] unrolled 24-round combinational core,
//               Lattice-SVP heuristic accelerator, and ultra-low-latency
//               TCAM interface. Targets 4 GHz on 1.4 nm nanosheet.
// Author      : OMEGA_CRACKER Design Team
// Release     : 1.0.0 - 2026-08-01 - Tape-out ready
// Node        : TSMC A14 / Intel 14A / Samsung SF1.4
// ============================================================================

`timescale 1ps/1fs
`default_nettype none

module OMEGA_CRACKER_V1_TOP
  import omega_pkg::*;
(
    // ---- Clocks & Reset -----------------------------------------------------
    input  wire                     clk_core_4ghz,       // Core clock 4 GHz
    input  wire                     clk_pcie_ref_100m,   // PCIe Gen6 refclk
    input  wire                     rst_n_async,         // Async active-low reset

    // ---- PCIe Gen6 x16 physical interface (SerDes) --------------------------
    input  wire [15:0]              pcie_rx_p,
    input  wire [15:0]              pcie_rx_n,
    output wire [15:0]              pcie_tx_p,
    output wire [15:0]              pcie_tx_n,

    // ---- HBM3E stack interface (2 stacks, 1024b each) -----------------------
    inout  wire [1023:0]            hbm0_dq,
    inout  wire [1023:0]            hbm1_dq,
    output wire [17:0]              hbm0_cmd,
    output wire [17:0]              hbm1_cmd,

    // ---- JTAG / DFT ---------------------------------------------------------
    input  wire                     tck,
    input  wire                     tms,
    input  wire                     tdi,
    output wire                     tdo,
    input  wire                     trst_n,

    // ---- Power/Thermal telemetry --------------------------------------------
    output wire [15:0]              thermal_sense,
    input  wire                     vdd_ok,
    input  wire                     scan_enable,
    input  wire                     test_mode
);

    // ------------------------------------------------------------------------
    // Reset synchronizer
    // ------------------------------------------------------------------------
    logic rst_n_sync;
    reset_sync u_rst_sync (
        .clk       (clk_core_4ghz),
        .rst_n_in  (rst_n_async),
        .rst_n_out (rst_n_sync)
    );

    // ------------------------------------------------------------------------
    // Internal fabric buses
    // ------------------------------------------------------------------------
    logic [4095:0] malu_a, malu_b, malu_n, malu_result;
    logic          malu_valid_in, malu_valid_out;

    logic [1599:0] keccak_state_in, keccak_state_out;
    logic          keccak_valid_in, keccak_valid_out;

    logic [8191:0] svp_basis_in;
    logic [8191:0] svp_vector_out;
    logic          svp_start, svp_done;

    logic [511:0]  tcam_key;
    logic          tcam_match;
    logic [15:0]   tcam_match_index;

    // ------------------------------------------------------------------------
    // M-ALU Core : 4096-bit Montgomery, RNS + wave-pipelined, 1-cycle effective
    // ------------------------------------------------------------------------
    m_alu_core_extreme u_malu (
        .clk        (clk_core_4ghz),
        .rst_n      (rst_n_sync),
        .a_in       (malu_a),
        .b_in       (malu_b),
        .n_in       (malu_n),
        .valid_in   (malu_valid_in),
        .result_out (malu_result),
        .valid_out  (malu_valid_out)
    );

    // ------------------------------------------------------------------------
    // Keccak-f[1600] : 24 rounds fully unrolled combinational, wave-pipelined
    // ------------------------------------------------------------------------
    keccak_unrolled_extreme u_keccak (
        .clk        (clk_core_4ghz),
        .rst_n      (rst_n_sync),
        .state_in   (keccak_state_in),
        .valid_in   (keccak_valid_in),
        .state_out  (keccak_state_out),
        .valid_out  (keccak_valid_out)
    );

    // ------------------------------------------------------------------------
    // Lattice SVP heuristic accelerator (reversible-logic inspired)
    // ------------------------------------------------------------------------
    lattice_svp_accelerator_extreme u_svp (
        .clk         (clk_core_4ghz),
        .rst_n       (rst_n_sync),
        .basis_in    (svp_basis_in),
        .start       (svp_start),
        .vector_out  (svp_vector_out),
        .done        (svp_done)
    );

    // ------------------------------------------------------------------------
    // TCAM ultra-low-latency (analog/mixed-signal wrapper, digital I/F here)
    // ------------------------------------------------------------------------
    tcam_interface_extreme u_tcam (
        .clk           (clk_core_4ghz),
        .rst_n         (rst_n_sync),
        .key           (tcam_key),
        .match         (tcam_match),
        .match_index   (tcam_match_index)
    );

    // ------------------------------------------------------------------------
    // Central control fabric, HBM controller, PCIe root complex
    // ------------------------------------------------------------------------
    omega_fabric u_fabric (
        .clk_core      (clk_core_4ghz),
        .clk_pcie_ref  (clk_pcie_ref_100m),
        .rst_n         (rst_n_sync),

        // to M-ALU
        .malu_a_o      (malu_a),
        .malu_b_o      (malu_b),
        .malu_n_o      (malu_n),
        .malu_vld_o    (malu_valid_in),
        .malu_res_i    (malu_result),
        .malu_vld_i    (malu_valid_out),

        // to Keccak
        .keccak_i_o    (keccak_state_in),
        .keccak_vi_o   (keccak_valid_in),
        .keccak_o_i    (keccak_state_out),
        .keccak_vo_i   (keccak_valid_out),

        // to SVP
        .svp_basis_o   (svp_basis_in),
        .svp_start_o   (svp_start),
        .svp_vec_i     (svp_vector_out),
        .svp_done_i    (svp_done),

        // to TCAM
        .tcam_key_o    (tcam_key),
        .tcam_match_i  (tcam_match),
        .tcam_idx_i    (tcam_match_index),

        // PCIe
        .pcie_rx_p     (pcie_rx_p),
        .pcie_rx_n     (pcie_rx_n),
        .pcie_tx_p     (pcie_tx_p),
        .pcie_tx_n     (pcie_tx_n),

        // HBM
        .hbm0_dq       (hbm0_dq),
        .hbm1_dq       (hbm1_dq),
        .hbm0_cmd      (hbm0_cmd),
        .hbm1_cmd      (hbm1_cmd)
    );

    // ------------------------------------------------------------------------
    // DFT wrapper : IEEE 1149.1 TAP + 1500 core wrappers
    // ------------------------------------------------------------------------
    dft_tap_wrapper u_tap (
        .tck (tck), .tms (tms), .tdi (tdi), .tdo (tdo), .trst_n (trst_n)
    );

    // ------------------------------------------------------------------------
    // Thermal telemetry
    // ------------------------------------------------------------------------
    thermal_sensor_array u_therm (
        .clk        (clk_core_4ghz),
        .rst_n      (rst_n_sync),
        .temp_out   (thermal_sense)
    );

endmodule : OMEGA_CRACKER_V1_TOP

`default_nettype wire
