// ============================================================================
// keccak_unrolled_extreme.sv
// Keccak-f[1600] fully unrolled: 24 rounds as one combinational cloud.
// Wave-pipelined for 4 GHz @ 1.4 nm.
// ============================================================================
`timescale 1ps/1fs
`default_nettype none

module keccak_unrolled_extreme (
    input  wire                clk,
    input  wire                rst_n,
    input  wire  [1599:0]      state_in,
    input  wire                valid_in,
    output logic [1599:0]      state_out,
    output logic               valid_out
);

    localparam int NUM_ROUNDS = 24;

    logic [1599:0] round_state [NUM_ROUNDS:0];
    assign round_state[0] = state_in;

    genvar r;
    generate
        for (r = 0; r < NUM_ROUNDS; r++) begin : g_rounds
            keccak_round #(.RC_IDX(r)) u_round (
                .state_in  (round_state[r]),
                .state_out (round_state[r+1])
            );
        end
    endgenerate

    // Wave-pipeline sample; SDC declares this as a wave-pipelined path
    // with 24 waves in flight (see set_multicycle_path in .sdc).
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_out <= '0;
            valid_out <= 1'b0;
        end else begin
            state_out <= round_state[NUM_ROUNDS];
            valid_out <= valid_in;
        end
    end

endmodule : keccak_unrolled_extreme

module keccak_round #(parameter int RC_IDX = 0) (
    input  wire  [1599:0] state_in,
    output logic [1599:0] state_out
);
    // Placeholder combinational: Theta -> Rho -> Pi -> Chi -> Iota
    // Real implementation instantiates the five sub-transforms.
    logic [1599:0] s_theta, s_rho, s_pi, s_chi;
    keccak_theta u_theta (.d_in(state_in), .d_out(s_theta));
    keccak_rho   u_rho   (.d_in(s_theta),  .d_out(s_rho));
    keccak_pi    u_pi    (.d_in(s_rho),    .d_out(s_pi));
    keccak_chi   u_chi   (.d_in(s_pi),     .d_out(s_chi));
    keccak_iota #(.RC_IDX(RC_IDX)) u_iota (.d_in(s_chi), .d_out(state_out));
endmodule

`default_nettype wire
