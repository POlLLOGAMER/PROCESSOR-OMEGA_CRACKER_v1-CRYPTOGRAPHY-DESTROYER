// ============================================================================
// lattice_svp_accelerator_extreme.sv
// Digital accelerator for SVP heuristics (LLL + enumeration + BKZ pruning).
// Implemented as a Toffoli/Fredkin-inspired reversible datapath in standard
// CMOS. Massively parallel branch exploration.
// ============================================================================
`timescale 1ps/1fs
`default_nettype none

module lattice_svp_accelerator_extreme #(
    parameter int DIM    = 128,   // lattice dimension
    parameter int COEF_W = 64     // coefficient width
)(
    input  wire                     clk,
    input  wire                     rst_n,
    input  wire  [DIM*COEF_W-1:0]   basis_in,
    input  wire                     start,
    output logic [DIM*COEF_W-1:0]   vector_out,
    output logic                    done
);

    typedef enum logic [2:0] {
        S_IDLE     = 3'd0,
        S_LOAD     = 3'd1,
        S_LLL      = 3'd2,
        S_ENUM     = 3'd3,
        S_REDUCE   = 3'd4,
        S_DONE     = 3'd5
    } state_t;

    state_t                    state, state_n;
    logic [DIM*COEF_W-1:0]     basis_reg;
    logic [DIM*COEF_W-1:0]     shortest_vec;
    logic [31:0]               iter_cnt;

    // Reversible-logic PE array (conceptual)
    logic [DIM*COEF_W-1:0]     pe_in, pe_out;
    reversible_pe_array #(.DIM(DIM), .COEF_W(COEF_W)) u_pe (
        .clk       (clk),
        .rst_n     (rst_n),
        .basis     (pe_in),
        .out_vec   (pe_out)
    );

    always_comb begin
        state_n = state;
        unique case (state)
            S_IDLE   : if (start) state_n = S_LOAD;
            S_LOAD   :             state_n = S_LLL;
            S_LLL    : if (iter_cnt > 32'd64)  state_n = S_ENUM;
            S_ENUM   : if (iter_cnt > 32'd512) state_n = S_REDUCE;
            S_REDUCE :             state_n = S_DONE;
            S_DONE   :             state_n = S_IDLE;
            default  :             state_n = S_IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_IDLE;
            basis_reg    <= '0;
            shortest_vec <= '0;
            iter_cnt     <= '0;
            done         <= 1'b0;
            vector_out   <= '0;
        end else begin
            state <= state_n;
            case (state)
                S_LOAD  : begin basis_reg <= basis_in; pe_in <= basis_in; iter_cnt <= '0; end
                S_LLL,
                S_ENUM,
                S_REDUCE: begin
                    pe_in       <= pe_out;
                    shortest_vec<= pe_out;
                    iter_cnt    <= iter_cnt + 1'b1;
                end
                S_DONE  : begin vector_out <= shortest_vec; done <= 1'b1; end
                default : done <= 1'b0;
            endcase
        end
    end

endmodule : lattice_svp_accelerator_extreme

`default_nettype wire
