# =============================================================================
# omega_cracker_v1_top.sdc — Synopsys Design Constraints 2.1
# Target: TSMC N3P (3 nm FinFET, HP)
# 12 corners, wave-pipelined ALU declared
# =============================================================================

set sdc_version 2.1

# -----------------------------------------------------------------------------
# Primary clocks
# -----------------------------------------------------------------------------
# Core clock retimed from 3.2 GHz (A14) -> 2.6 GHz (N3P) to close timing on
# the wave-pipelined ALU with N3P RC parasitics.
create_clock -name CLK_CORE   -period  384.6 -waveform {0 192.3}  [get_ports CLK_CORE_IN]
create_clock -name CLK_KECCAK -period  384.6 -waveform {0 192.3}  [get_ports CLK_KECCAK_IN]
create_clock -name CLK_LATT   -period  500.0 -waveform {0 250.0}  [get_ports CLK_LATT_IN]
create_clock -name CLK_PCIE   -period  125.0 -waveform {0  62.5}  [get_ports CLK_PCIE_REF]
create_clock -name CLK_HBM0   -period  312.5 -waveform {0 156.25} [get_ports CLK_HBM0_REF]
create_clock -name CLK_HBM1   -period  312.5 -waveform {0 156.25} [get_ports CLK_HBM1_REF]

# Uncertainty (jitter + margin) — slightly larger on N3P
set_clock_uncertainty -setup 22 [all_clocks]
set_clock_uncertainty -hold   14 [all_clocks]

# -----------------------------------------------------------------------------
# Wave-pipelining declaration for the M-ALU core
# 4 waves in flight across the RNS 66-lane datapath
# -----------------------------------------------------------------------------
set_wave_pipeline -waves 4 [get_pins u_m_alu_core/rns_pipe_reg_*/D]
set_multicycle_path -setup 4 -from [get_pins u_m_alu_core/stage0_reg_*/CK] \
                              -to   [get_pins u_m_alu_core/stage3_reg_*/D]
set_multicycle_path -hold  3 -from [get_pins u_m_alu_core/stage0_reg_*/CK] \
                              -to   [get_pins u_m_alu_core/stage3_reg_*/D]

# -----------------------------------------------------------------------------
# 12 sign-off PVT corners (N3P std lib)
#   FFG / SS / TT  ×  0.675 / 0.750 / 0.825 V  ×  −40°C / 25°C / 125°C
# -----------------------------------------------------------------------------
# Corners declared to PrimeTime via .mmmc; SDC references logical scenarios:
set_operating_conditions -analysis_type on_chip_variation
set_case_analysis 0 [get_ports SCAN_MODE]
set_case_analysis 0 [get_ports DFT_TEST_MODE]

# -----------------------------------------------------------------------------
# IO constraints
# -----------------------------------------------------------------------------
set_input_delay  -clock CLK_PCIE -max 15.0 [get_ports PCIE_RX_P*]
set_input_delay  -clock CLK_PCIE -min  4.0 [get_ports PCIE_RX_P*]
set_output_delay -clock CLK_PCIE -max 12.0 [get_ports PCIE_TX_P*]
set_output_delay -clock CLK_PCIE -min  3.0 [get_ports PCIE_TX_P*]

set_input_delay  -clock CLK_HBM0 -max 25.0 [get_ports HBM0_DQ*]
set_output_delay -clock CLK_HBM0 -max 22.0 [get_ports HBM0_DQ*]
set_input_delay  -clock CLK_HBM1 -max 25.0 [get_ports HBM1_DQ*]
set_output_delay -clock CLK_HBM1 -max 22.0 [get_ports HBM1_DQ*]

# -----------------------------------------------------------------------------
# False paths / async crossings
# -----------------------------------------------------------------------------
set_false_path -from [get_ports PORST_N]
set_false_path -from [get_ports JTAG_TCK] -to [all_registers]
set_false_path -through [get_pins u_cdc_sync_*/sync_reg_0/D]

# -----------------------------------------------------------------------------
# Load / drive
# -----------------------------------------------------------------------------
set_load 0.5 [all_outputs]
set_driving_cell -lib_cell N3P_BUFX8 [all_inputs]

# End of file
