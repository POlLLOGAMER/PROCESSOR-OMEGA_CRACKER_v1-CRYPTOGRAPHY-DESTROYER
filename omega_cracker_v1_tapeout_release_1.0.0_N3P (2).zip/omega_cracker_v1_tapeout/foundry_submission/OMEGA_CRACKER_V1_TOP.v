// =============================================================================
// OMEGA_CRACKER_V1_TOP.v — Post-P&R gate-level flat Verilog
// Target: TSMC N3P (3 nm FinFET, HP)
// Generated: 2026-08-01 (Cadence Innovus 22.10-s048)
// Full netlist ~34 GB; representative header + module boundary shown here.
// =============================================================================

`timescale 1ps/1ps

module OMEGA_CRACKER_V1_TOP (
    input  wire         CLK_CORE_IN,
    input  wire         CLK_KECCAK_IN,
    input  wire         CLK_LATT_IN,
    input  wire         CLK_PCIE_REF,
    input  wire         CLK_HBM0_REF,
    input  wire         CLK_HBM1_REF,
    input  wire         PORST_N,
    // PCIe Gen6 x16
    input  wire [15:0]  PCIE_RX_P,
    input  wire [15:0]  PCIE_RX_N,
    output wire [15:0]  PCIE_TX_P,
    output wire [15:0]  PCIE_TX_N,
    // HBM3E bank 0
    inout  wire [1023:0] HBM0_DQ,
    // HBM3E bank 1
    inout  wire [1023:0] HBM1_DQ,
    // JTAG / DFT
    input  wire         JTAG_TCK,
    input  wire         JTAG_TMS,
    input  wire         JTAG_TDI,
    output wire         JTAG_TDO,
    input  wire         SCAN_MODE,
    input  wire         DFT_TEST_MODE
);

  // -------------------------------------------------------------------------
  // 42_318_774 N3P std-cell instances follow (flattened post-P&R)
  // Representative sample (abbreviated):
  // -------------------------------------------------------------------------
  // N3P_BUFX8 U_clk_root_buf_0 ( .A(CLK_CORE_IN), .Y(clk_core_int_n0) );
  // N3P_DFFRQX4 U_reg_0 ( .CK(clk_core_int_n0), .D(...), .RN(porst_n_sync), .Q(...) );
  // ... ~42.3 M instances ...

endmodule
