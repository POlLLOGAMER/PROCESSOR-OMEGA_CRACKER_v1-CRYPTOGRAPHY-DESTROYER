#!/bin/bash
# =============================================================================
# 00_run_signoff_flow.sh — Full sign-off flow driver
# Target: TSMC N3P (3 nm FinFET, HP) — PDK v1.0 rev 2026-05-20
# Must be executed on a site with all EDA licenses + PDK under NDA.
# Estimated wall-clock: 18-26 h on 512-core RHEL 9 cluster.
# =============================================================================
set -euo pipefail

export PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export DESIGN="OMEGA_CRACKER_V1_TOP"

export FOUNDRY="TSMC"
export NODE="N3P"
export PDK_VER="v1p0_rev2026-05-20"
export PDK_ROOT="${PDK_ROOT:?PDK_ROOT env var must point to TSMC N3P PDK under NDA}"

echo "============================================================"
echo "OMEGA_CRACKER_v1 sign-off flow — $FOUNDRY $NODE $PDK_VER"
echo "Project root: $PROJECT_ROOT"
echo "============================================================"

# 1. Synthesis (Synopsys Fusion Compiler)
echo "[1/8] Synthesis…"
fc_shell -f  "$PROJECT_ROOT/scripts/syn/run_synth.tcl"        | tee syn.log

# 2. Place & Route (Cadence Innovus)
echo "[2/8] Place & Route…"
innovus -files "$PROJECT_ROOT/scripts/pnr/run_pnr.tcl"        | tee pnr.log

# 3. Parasitic extraction (Synopsys StarRC)
echo "[3/8] StarRC extraction (N3P RC tech)…"
StarXtract -clean -cmd "$PROJECT_ROOT/scripts/rc/run_starrc.cmd" | tee rc.log

# 4. STA (Synopsys PrimeTime) — 12 corners
echo "[4/8] PrimeTime STA (12 corners, wave-pipe)…"
pt_shell -f "$PROJECT_ROOT/scripts/sta/run_pt.tcl"            | tee sta.log

# 5. DRC (Siemens Calibre nmDRC)
echo "[5/8] Calibre nmDRC (N3P sign-off deck)…"
calibre -drc -turbo "$PROJECT_ROOT/scripts/drc/N3P_drc.rul"   | tee drc.log

# 6. LVS (Siemens Calibre nmLVS)
echo "[6/8] Calibre nmLVS…"
calibre -lvs -hier -turbo "$PROJECT_ROOT/scripts/lvs/N3P_lvs.rul" | tee lvs.log

# 7. ERC / ESD / Latch-up (Siemens Calibre PERC)
echo "[7/8] Calibre PERC (ERC/ESD/LU)…"
calibre -perc "$PROJECT_ROOT/scripts/perc/N3P_perc.rul"       | tee perc.log

# 8. Power integrity + EM (Ansys RedHawk-SC)
echo "[8/8] RedHawk-SC (static+dynamic IR + EM)…"
redhawk -run "$PROJECT_ROOT/scripts/pi/run_redhawk.tcl"       | tee pi.log

# Finalize: OASIS + manifest with real SHA-256
echo "Emitting final OASIS…"
oa2oas -in "${DESIGN}.oa" -out "$PROJECT_ROOT/foundry_submission/${DESIGN}.oas"

echo "Updating TAPEOUT_MANIFEST.yaml with real SHA-256…"
python3 "$PROJECT_ROOT/scripts/tools/refresh_manifest.py"

echo "============================================================"
echo "SIGN-OFF FLOW COMPLETE — package ready for TSMC-Online upload"
echo "============================================================"
